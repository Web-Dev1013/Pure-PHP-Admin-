<div class="container">
    <div class="row">
        <div class="h1 p-5 text-gold font-weight-bold">
            <p class="mx-auto">This is dashboard</p>
        </div>
    </div>
</div>