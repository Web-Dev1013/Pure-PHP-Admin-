$(function () {
  //  ********************************************** Main table *************************************************
  /* var description
    sp_ct_id = survey page custom category id
  */
  var surveyPages_table = $("#surveyPages_table").DataTable({
    "columns": [{
        "title": "User",
        "data": "user"
      },
      {
        "title": "SurveyCode",
        "data": "codeHash"
      },
      {
        "title": "Survey_code_name",
        "data": "codeName"
      },
      {
        "title": "Survey_page_header",
        "data": "pageHeader"
      },
      {
        "title": "page_display_order",
        "data": "pageOrder"
      },
    ],
    "filter": false,
    "info": false,
    "paginate": true
  });
  $(".dataTables_paginate.paging_simple_numbers").addClass("float-right mb-2");
  $("#surveyPages_table_length").hide();
  $("#surveyPages_table_length select").addClass("form-control mx-auto w-50 border-warning text-gold font-weight-bold");

  //  ************************************************ Recommendation Table *****************************************
  var rec_table = $("#recommendation").DataTable({
    "columns": [{
        "title": "Survey Page",
        "data": "survey_page"
      },
      {
        "title": "Date",
        "data": "date"
      },
      {
        "title": "Recommendation",
        "data": "recommendation"
      }
    ],
    "filter": false,
    "info": false,
    "paginate": true
  });
  $(".dataTables_paginate.paging_simple_numbers").addClass("float-right mb-2");
  $("#recommendation_length").hide();
  $("#recommendation_length select").addClass("form-control mx-auto w-50 border-warning text-gold font-weight-bold");

  //  ************************************************** Feedback Table ***********************************************
  var fb_table = $("#feedback").DataTable({
    "columns": [{
        "title": "Survey Page",
        "data": "survey_page"
      },
      {
        "title": "Date",
        "data": "date"
      }, {
        "title": "Feedback",
        "data": "feedback"
      }
    ],
    "filter": false,
    "info": false,
    "paginate": true
  });
  $(".dataTables_paginate.paging_simple_numbers").addClass("float-right mb-2");
  $("#feedback_length").hide();
  $("#feedback_length select").addClass("form-control mx-auto w-50 border-warning text-gold font-weight-bold");
  // *********************************************************** Init define ********************************************
  // Move row      
  $.fn.updateOrder = function (data) {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: 'POST',
      data: {
        type: "move_row",
        position: data
      },
      async: false,
      success: function (res) {
        if (res == "success") {
          $(".alert-success .notification").html("Successfully Changed!");
          $(".alert-success").addClass("alert-active");
          setTimeout(function () {
            $(".alert-success").removeClass("alert-active");
          }, 2000);
        }
      }
    });
  }
  $.fn.move_template_row = function () {
    $("#template tbody").sortable({
      delay: 150,
      stop: function () {
        var selectedData = new Array();
        $('#template tbody>tr').each(function () {
          selectedData.push($(this).attr("id"));
        });
        $.fn.updateOrder(selectedData);
      }
    });
  }

  // Init SurveyPage Table
  $.fn.init_surveyPage_table = function () {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "init_surveyPage_table",
        sc_id: window.localStorage.getItem("sc_id")
      },
      async: false,
      success: function (res) {
        if (res == "") {
          // $(".alert-success").html("Add a new survey page to get started!");
          // $(".alert-success").addClass("alert-active");
          // setTimeout(function () {
          //   $(".alert-success").removeClass("alert-active");
          // }, 2000);
          surveyPages_table.clear();
          surveyPages_table.draw();
        } else {
          res = JSON.parse(res);
          surveyPages_table.clear();
          $.each(res, function (index, value) {
            var rowIndex = surveyPages_table.row.add(value);
            var row = $('#surveyPages_table').dataTable().fnGetNodes(rowIndex);
            $(row).attr('id', res[index]["id"]);
          });
          surveyPages_table.draw();
          var page_search = "";
          for (x in res) {
            page_search += "<option value='" + res[x]["id"] + "'>" + res[x]["codeName"] + "</option>";
          }
          $("#surveypage_search").html(page_search);
          $("#surveypage_search").select2();
        }
      }
    });
  }

  // Update template value
  $.fn.update_template_value = function (tr_id) {
    for (var i = 0; i < $("#template tr").length; i++) {
      var level_id = $(".sp-level-btn-group .btn-warning").attr("value");
      var template_id = $("#template tr:eq(" + i + ")").attr("id");
      var value = $("#template tr:eq(" + i + ")").find("td").eq(4).html().replace(",", "");
      var percentage = $("#template tr:eq(" + i + ")").find("td").eq(6).html().replace(",", "");
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "update_template_value",
          level_id: level_id,
          template_id: template_id,
          value: value,
          percentage: percentage
        },
        async: false,
        success: function (res) {
          if (res == "success") {

          }
        }
      });
    }
  }

  //  Base detail Data
  $.fn.sp_base_data = function (sc_id) {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "sp_base_data",
        sc_id: sc_id
      },
      async: false,
      success: function (res) {
        res = JSON.parse(res);
        $("#sp_survey_co_id").val(res.surveyed_co_id);
        $("#sp_purchased_co_id").val(res.purchased_co_id);
        $("#sp_area").val(res.area);
        $("#sp_financial_year").val(res.financial_year);
        $("#sp_fiscal_eoy").val(res.fiscal_year_ends);
        $("#sp_month_start").val(res.month_start);
        $("#sp_month_end").val(res.month_end);
        $("#sp_period").val(res.period_id);
        $(".sp-level-btn-group button").removeClass("btn-warning");
        $(".sp-level-btn-group button").addClass("btn-outline-warning");
        $("#sp_" + res.level_id).addClass("btn-warning");
        $("#sp_" + res.level_id).removeClass("btn-outline-warning");
      }
    })
  }

  //  Init template function
  var value_arr = [];
  $.fn.display_template = function (res) {
    res = JSON.parse(res);
    var template_data = "";
    var template_thead_data = "";
    var template_tbody_data = "";
    var template_tfoot_data = "";
    value_arr = [];
    var value_sum = 0;
    var value_total;
    for (x in res) {
      value_arr.push(res[x]["value"]);
      if (res[x]["flag_id"] == 1) {
        value_total = res[x]["value"];
        template_thead_data = "<thead><tr id='" + res[x]["id"] + "'><td></td><td><img src='assets/image/page1/" + res[x]["icon_url"] + "' width='30px' height='30px'></td><td>" + res[x]["name"] + "<p class='sup text-gold'>" + res[x]["category_code"] + "</p></td><td><span class='sp_current'> " + (res[x]["currency"] == undefined ? " " : res[x]["currency"]) + " </span></td><td class='total-value bg-warning text-right' contentEditable>" + res[x]["value"] + "</td><td><span class='page_unit sup'>" + res[x]["unit"] + "</span></td><td class='all-percentage'>" + res[x]["percentage"] + "</td></tr></thead><tbody class='row_position'>";
      }
      if (res[x]["flag_id"] == 0) {
        value_sum += Number(res[x]["value"]);
        template_tbody_data += "<tr id='" + res[x]["id"] + "'><td><span class='eye p-2'><i class='fas fa-eye fa-lg text-gold'></i></span><input type='hidden' name='false' id='hidden_" + res[x]["id"] + "'></td><td><img src='assets/image/page1/" + res[x]["icon_url"] + "' width='30px' height='30px'></td><td>" + res[x]["name"] + "<p class='sup text-gold'>" + res[x]["category_code"] + "</p></td><td><span class='sp_current'> " + (res[x]["currency"] == undefined ? " " : res[x]["currency"]) + " </span></td><td class='value' contentEditable>" + res[x]["value"] + "</td><td><span class='page_unit sup'>" + res[x]["unit"] + "</span></td><td class='percentage' contentEditable>" + res[x]["percentage"] + "</td></tr>";
      }
      if (res[x]["flag_id"] == 2) {
        template_tfoot_data = "</tbody><tfoot><tr id='" + res[x]["id"] + "'><td><span data-toggle='modal' data-target='#new_template_data' class='p-2'><i class='fas fa-plus-circle text-gold fa-2x'></i></span></td><td><i class='fas fa-question-circle fa-2x text-gold'></i></td><td>" + res[x]["name"] + "<p class='sup text-gold'>" + res[x]["category_code"] + "</p></td><td><span class='sp_current'> " + (res[x]["currency"] == undefined ? " " : res[x]["currency"]) + " </span></td><td class='value'>" + (Number(value_total) - value_sum) + "</td><td><span class='page_unit sup'>" + res[x]["unit"] + "</span></td><td class='sub-percentage'>" + (Number(value_total) - value_sum) / (Number(value_total)) + "</td></tr></tfoot>";
      }
    }
    template_data = template_thead_data + template_tbody_data + template_tfoot_data;
    return template_data;
  };

  $.fn.init_template = function () {
    var sp_header_user;
    if ($("#sp_header_user").html() != "") {
      sp_header_user = "none";
    } else {
      sp_header_user = $("#sp_header_user").html();
    }
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "init_template",
        sc_id: window.localStorage.getItem("sc_id"),
        sp_header_user: sp_header_user,
        level_id: $(".sp-level-btn-group .btn-warning").attr("value")
      },
      async: false,
      success: function (res) {
        $("#template").html($.fn.display_template(res));
        // Auto Numeric
        new AutoNumeric.multiple('.value', {
          currencySymbol: "",
          caretPositionOnFocus: "start",
          modifyValueOnWheel: false,
          decimalCharacter: separate_format,
          digitGroupSeparator: group_separate,
          decimalPlaces: decimal_format
        });
        new AutoNumeric('.total-value', {
          currencySymbol: "",
          caretPositionOnFocus: "start",
          modifyValueOnWheel: false,
          decimalCharacter: separate_format,
          digitGroupSeparator: group_separate,
          decimalPlaces: decimal_format
        });
        $.fn.move_template_row();
      }
    });
  }

  // Base Detail data and formatting option
  $.fn.detail_and_formatting_data = function (tr_id) {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "detail_and_formatting_data",
        level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
        tr_id: tr_id
      },
      success: function (res) {
        if (res == "failed") {
          $(".alert-danger .notification").html("There is no data registered!");
          $(".alert-danger").addClass("alert-active");
          setTimeout(function () {
            $(".alert-danger").removeClass("alert-active");
          }, 2000);
        } else {
          res = JSON.parse(res);
          $("#sp_name_search").val(res.survey_page_header_user);
          $("#sp_header_user").html(res.survey_page_header_user);
          $("#sp_tagline_user").html(res.survey_page_tagline_user);
          $("#sp_name_admin").val(res.survey_page_name_admin);
          $("#sp_description").val(res.survey_page_description_admin);
          $("#sp_level1_search").val(res.survey_page_template_id);
          $("#sp_level1_search").trigger("change");
          $("#sp_unit").val(res.survey_page_unit);
          for (n in $(".currency_format button")) {
            if ($(".currency_format button").eq(n).html() == res.survey_page_currency) {
              $(".currency_format button").addClass("btn-outline-warning");
              $(".currency_format button").removeClass("btn-warning");
              $(".currency_format button").eq(n).addClass("btn-warning");
              $(".currency_format button").eq(n).removeClass("btn-outline-warning");
            }
          }
          $("#" + res.survey_page_separator).addClass("btn-warning");
          $("#" + res.survey_page_separator).removeClass("btn-outline-warning");
          $("#dc_" + res.survey_page_decimals).addClass("btn-warning");
          $("#dc_" + res.survey_page_decimals).removeClass("btn-outline-warning");
        }
      }
    });
  }

  //  Init level categories 
  $.fn.init_level_categories = function () {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "init_level_categories",
        sc_id: window.localStorage.getItem("sc_id"),
        level_id: $(".sp-level-btn-group .btn-warning").attr("value")
      },
      success: function (res) {
        res = JSON.parse(res);
        l_c_data = res;
      }
    });
  }

  // Template table define.
  $.fn.template_table_data = function (tr_id) {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "template_table_data",
        tr_id: tr_id,
        level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
      },
      success: function (res) {
        if (res == "failed") {
          $(".alert-danger .notification").html("There is no data registered!");
          $(".alert-danger").addClass("alert-active");
          setTimeout(function () {
            $(".alert-danger").removeClass("alert-active");
          }, 2000);
        } else {
          $("#template").html($.fn.display_template(res));
          // Auto Numeric
          new AutoNumeric.multiple('.value', {
            currencySymbol: "",
            caretPositionOnFocus: "start",
            modifyValueOnWheel: false,
            decimalCharacter: separate_format,
            digitGroupSeparator: group_separate,
            decimalPlaces: decimal_format
          });
          new AutoNumeric('.total-value', {
            currencySymbol: "",
            caretPositionOnFocus: "start",
            modifyValueOnWheel: false,
            decimalCharacter: separate_format,
            digitGroupSeparator: group_separate,
            decimalPlaces: decimal_format
          });
          $.fn.init_level_categories();
        }
      }
    });
  }
  // Init recommendation table
  $.fn.init_recommendation = function () {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "init_recommendation",
        level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
        sc_id: window.localStorage.getItem("sc_id")
      },
      success: function (res) {
        if (res != "") {
          res = JSON.parse(res);
          rec_table.clear();
          $.each(res, function (index, value) {
            var rowIndex = rec_table.row.add(value);
            var row = $('#recommendation').dataTable().fnGetNodes(rowIndex);
            $(row).attr('id', res[index]["id"]);
          });
          rec_table.draw();
        }
      }
    })
  }

  // Init recommendation table
  $.fn.init_feedback = function () {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "init_feedback",
        level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
        sc_id: window.localStorage.getItem("sc_id")
      },
      success: function (res) {
        if (res != "") {
          res = JSON.parse(res);
          fb_table.clear();
          $.each(res, function (index, value) {
            var rowIndex = fb_table.row.add(value);
            var row = $('#feedback').dataTable().fnGetNodes(rowIndex);
            $(row).attr('id', res[index]["id"]);
          });
          fb_table.draw();
        }
      }
    })
  }

  // Display survey page table
  $.fn.display_survey_page_table = function (tr_id) {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "display_selected_surveyPages_data",
        tr_id: tr_id
      },
      async: false,
      success: function (res) {
        res = JSON.parse(res);
        $("#sp_survey_co_id").val(res.surveyed_co_id);
        $("#sp_purchased_co_id").val(res.purchased_co_id);
        $("#sp_area").val(res.area);
        $("#sp_fiscal_eoy").val(res.fiscal_year_ends);
        $("#sp_period").val(res.period_id);
        $("#sp_financial_year").val(res.financial_year);
        $("#sp_month_start").val(res.month_start);
        $("#sp_month_end").val(res.month_end);
        $("#sp_period").trigger("change");
        $("#sp_purchased_co_id").trigger("change");
        $("#sp_fiscal_eoy").trigger("change");
        window.localStorage.setItem("surveycode_id", res.surveycode_id);
        window.localStorage.setItem("surveylogin_id", res.surveylogin_id);
        window.localStorage.setItem("level_id", res.level_id);
        level_temp = res.level_id;
        for (x in $(".sp-level-btn-group button")) {
          if ($(".sp-level-btn-group button:eq(" + x + ")").attr("value") == res.level_id) {
            $(".sp-level-btn-group button").removeClass("btn-warning");
            $(".sp-level-btn-group button").addClass("btn-outline-warning");
            $(".sp-level-btn-group button:eq(" + x + ")").addClass("btn-warning");
            $(".sp-level-btn-group button:eq(" + x + ")").removeClass("btn-outline-warning");
          }
        }
        $.fn.detail_and_formatting_data(tr_id);
        $.fn.template_table_data(tr_id);
      }
    });
  }

  // Init period
  $.fn.sp_init_period = function () {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "init_period"
      },
      success: function (res) {
        var period_data = "";
        res = JSON.parse(res);
        for (x in res) {
          period_data += "<option value='" + res[x]["id"] + "'>" + res[x]["name"] + "</option>";
        }
        $("#sp_period").html(period_data);
      }
    })
  }

  // Init Company
  $.fn.init_sp_company = function () {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "init_company"
      },
      success: function (res) {
        var init_company_data = "";
        res = JSON.parse(res);
        for (x in res) {
          init_company_data += "<option value='" + res[x]["id"] + "'>" + res[x]["name"] + "</option>";
        }
        $("#sp_survey_co_id").html(init_company_data);
        $("#sp_purchased_co_id").html(init_company_data);
      }
    });
  }

  // Init Base Categories Name
  $.fn.init_base_categories = function () {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "init_base_categories"
      },
      success: function (res) {
        res = JSON.parse(res);
        var b_c_data = "";
        for (x in res) {
          b_c_data += "<option value='" + res[x]["id"] + "'>" + res[x]["template_name"] + "</option>";
        }
        $("#sp_level1_search").html(b_c_data);
      }
    });
  }


  $("#page_item").on("click", function () {
    var sc_id = window.localStorage.getItem("sc_id");
    if (sc_id == null) {
      $(".alert-danger .notification").html("No survey code selected!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2000);
    } else {
      $.fn.sp_init_period();
      $.fn.init_sp_company();
      $.fn.init_base_categories();
      $.fn.sp_base_data(sc_id);
      $.fn.init_surveyPage_table();
      $.fn.init_recommendation();
      $.fn.init_feedback();
      new AutoNumeric.multiple('.value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: ".",
        digitGroupSeparator: ",",
        decimalPlaces: 2
      });
      $("#sp_fiscal_eoy").select2();
      $("#sp_survey_co_id").select2();
      $("#sp_purchased_co_id").select2();
      $("#sp_period").select2();
      $("#sp_level1_search").select2();
    }

    // When dblclick,
    $("#surveyPages_table tbody").on("dblclick", function (e) {
      var tr_id = $(e.target).parent().attr("id");
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "get_url_by_dblclick",
          tr_id: tr_id
        },
        success: function (res) {
          if (res != "") {
            res = JSON.parse(res);
            var url = "https://leaderofone.com/work2/?un=" + res.username_hash + "&pw=" + res.password_hash + "&ac=" + res.survey_code_hash;
            $("#url_hidden").val(url);
            var copyText = document.getElementById("url_hidden");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            $(".alert-success .notification").html("URL is successfully copied!");
            $(".alert-success").addClass("alert-active");
            setTimeout(function () {
              $(".alert-success").removeClass("alert-active");
            }, 2000);
          }
        }
      });
    });

    // Company title define
    var company_title = window.localStorage.getItem("init_company_title");
    res = JSON.parse(company_title);
    $("#sp_title_company_name").html(res.company_name);
    $("#sp_title_area").html(res.area);
    $("#sp_title_period").html(res.financial_year + " - " + res.period + "( " + res.month_start + " - " + res.month_end + " )");
    $("#sp_title_email").html(res.email);
    $("#sp_title_level").html(res.level_id);
    $("#sp_title_company_ticker").html(res.company_ticker);
  });

  $.fn.move_template_row();

  //  Hide tr of expenditure table.
  $("#template").on("click", function (e) {
    if ($(e.target).parent().hasClass("fa-eye") == true || $(e.target).hasClass("fa-eye") == true) {
      $(e.target).parents("td").find(".fa-eye").addClass("fa-eye-slash");
      $(e.target).parents("tr").css("background", "#ff222233");
      $(e.target).parents("tr").find("input[type=hidden]").val($(e.target).parents("tr").find(".value").html());
      var value_temp = (Number($("#template tfoot").find(".value").html().replace(",", "")) + Number($(e.target).parents("tr").find(".value").html().replace(",", "")));
      var percentage_temp = (Number(value_temp) / Number($("#template thead").find(".total-value").html().replace(",", ""))).toFixed(10);
      $("#template tfoot").find(".value").html(value_temp);
      $("#template tfoot").find(".sub-percentage").html(percentage_temp);
      $(e.target).parents("tr").find(".value").html("0");
      $(e.target).parents("tr").find(".percentage").html("0");
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "hidden_row",
          level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
          category_id: $(e.target).parents("tr").attr("id")
        }
      });
      // Auto Numeric
      new AutoNumeric.multiple('.value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: separate_format,
        digitGroupSeparator: group_separate,
        decimalPlaces: decimal_format
      });
      new AutoNumeric('.total-value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: separate_format,
        digitGroupSeparator: group_separate,
        decimalPlaces: decimal_format
      });
    } else if ($(e.target).parent().hasClass("fa-eye-slash") == true || $(e.target).hasClass("fa-eye-slash") == true) {
      $(e.target).parents("td").find(".fa-eye-slash").addClass("fa-eye");
      $(e.target).parents("tr").css("background", "#fff");
      var hidden_value = Number($(e.target).parents("tr").find("input[type=hidden]").val().replace(",", "")).toFixed(2);
      var hidden_percentage = (hidden_value / Number($("#template thead").find(".total-value").html().replace(",", ""))).toFixed(10);
      $(e.target).parents("tr").find(".value").html(hidden_value);
      $(e.target).parents("tr").find(".percentage").html(hidden_percentage);
      $("#template tfoot").find(".value").html((Number($("#template tfoot").find(".value").html().replace(",","")) - hidden_value).toFixed(2));
      $("#template tfoot").find(".sub-percentage").html((Number($("#template tfoot").find(".sub-percentage").html()) - hidden_percentage).toFixed(10));
      $(e.target).parents("tr").find("input[type=hidden]").val("");
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "show_row",
          level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
          category_id: $(e.target).parents("tr").attr("id"),
        }
      });
      // Auto Numeric
      new AutoNumeric.multiple('.value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: separate_format,
        digitGroupSeparator: group_separate,
        decimalPlaces: decimal_format
      });
      new AutoNumeric('.total-value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: separate_format,
        digitGroupSeparator: group_separate,
        decimalPlaces: decimal_format
      });
    }
  });

  // When click Load button on survey page detail
  $("#level_category_load").on("click", function () {
    if ($("#sp_name_search").val() != "") {
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "level_category_load",
          keyword: window.localStorage.getItem("sp_ct_id"),
          level_id: $(".sp-level-btn-group .btn-warning").attr("value")
        },
        success: function (res) {
          if (res == "no_page") {
            $(".alert-danger .notification").html("This page does not exist!");
            $(".alert-danger").addClass("alert-active");
            setTimeout(function () {
              $(".alert-danger").removeClass("alert-active");
            }, 2000);
          } else {
            res = JSON.parse(res);
            $("#sp_name_admin").val(res.name);
            $("#sp_description").val(res.description);
            $("#sp_unit").val(res.unit);
            $("#sp_hidden_temp").val(res.id);
            $(".format button").removeClass("btn-warning");
            $(".format button").addClass("btn-outline-warning");
            for (x in $(".currency_format button")) {
              if ($(".currency_format button:eq(" + x + ")").html() == res.currency) {
                $(".currency_format button").removeClass("btn-warning");
                $(".currency_format button").addClass("btn-outline-warning");
                $(".currency_format button:eq(" + x + ")").addClass("btn-warning");
                $(".currency_format button:eq(" + x + ")").removeClass("btn-outline-warning");
              }
            }
            $("#" + res.separator).addClass("btn-warning");
            $("#" + res.separator).removeClass("btn-outline-warning");
            $("#dc_" + res.decimal).addClass("btn-warning");
            $("#dc_" + res.decimal).removeClass("btn-outline-warning");
            $.fn.surveypage_load();
          }
        }
      });
    } else {
      $(".alert-danger .notification").html("Please select survey page name!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2000);
    }
  });

  // When click Save template as button
  $("#save_template_as").on("click", function () {
    if ($("#sp_header_user").html() == "") {
      $(".alert-danger .notification").html("Please fill all of the fields!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2000);
    }
    // if (saved_flag == false) {
    //   $(".alert-danger .notification").html("Please save this survey page before saving as a template!");
    //   $(".alert-danger").addClass("alert-active");
    //   setTimeout(function () {
    //     $(".alert-danger").removeClass("alert-active");
    //   }, 2000);
    // }
    // if (saved_flag == true) {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "save_template_as",
        level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
        sc_id: window.localStorage.getItem("sc_id"),
        sp_header_user: $("#sp_header_user").html(),
        sp_bc_id: $("#sp_level1_search").val()
      },
      success: function (res) {
        if (res == "success") {
          $(".alert-success .notification").html("Successfully saved as template!");
          $(".alert-success").addClass("alert-active");
          setTimeout(function () {
            $(".alert-success").removeClass("alert-active");
          }, 2000);
        } else if (res == "exist") {
          $(".alert-danger .notification").html("This template already exists!");
          $(".alert-danger").addClass("alert-active");
          setTimeout(function () {
            $(".alert-danger").removeClass("alert-active");
          }, 2000);
        }
      }
    });
    // }
  });

  // When click Update template 
  $("#update_template").on("click", function () {
    if ($("#sp_name_search").val() == "" || $("#sp_header_user").html() == "") {
      $(".alert-danger .notification").html("Please fill all of the fields!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2000);
    } else {
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "update_template",
          sc_id: window.localStorage.getItem("sc_id"),
          sp_template_id: $("#sp_level1_search").val(),
          level_id: $(".sp-level-btn-group .btn-warning").attr("value")
        },
        async: false,
        success: function (res) {
          if (res == "success") {
            $.ajax({
              url: "model/pages/surveyPages_model.php",
              type: "POST",
              data: {
                type: "save_template_as",
                level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
                sc_id: window.localStorage.getItem("sc_id"),
                sp_header_user: $("#sp_header_user").html(),
                sp_bc_id: $("#sp_level1_search").val()
              },
              async: false,
              success: function (res) {
                if (res == "success") {
                  $(".alert-success .notification").html("Successfully updated as template!");
                  $(".alert-success").addClass("alert-active");
                  setTimeout(function () {
                    $(".alert-success").removeClass("alert-active");
                  }, 2000);
                } else if (res == "exist") {
                  $(".alert-danger .notification").html("This template already exists!");
                  $(".alert-danger").addClass("alert-active");
                  setTimeout(function () {
                    $(".alert-danger").removeClass("alert-active");
                  }, 2000);
                }
              }
            });
          }
        }
      });
    }
  });

  // Save survey page
  $("#save_page").on("click", function () {
    var sc_id = window.localStorage.getItem("sc_id");
    var tr_id = $("#surveyPages_table .table-active").attr("id");
    if ($("#sp_header_user").html() != "") {
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "save_surveyPage",
          sp_name: $("#sp_name_search").val(),
          sp_level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
          sp_template_id: $("#sp_level1_search").val(),
          sp_name_admin: $("#sp_name_admin").val(),
          sp_description: $("#sp_description").val(),
          sp_currency: $(".currency_format .btn-warning").html(),
          sp_separate: $(".separate_format .btn-warning").attr("id"),
          sp_decimal: $(".decimal_format .btn-warning").html(),
          sp_unit: $("#sp_unit").val(),
          sp_header_user: $("#sp_header_user").html(),
          sp_tagline_user: $("#sp_tagline_user").html(),
          sc_id: sc_id
        },
        async: false,
        success: function (res) {
          if (res == "success") {
            // saved_flag = true;
            $(".alert-success .notification").html("Successfully saved!");
            $(".alert-success").addClass("alert-active");
            setTimeout(function () {
              $(".alert-success").removeClass("alert-active");
            }, 2000);
            $.fn.init_surveyPage_table();
          } else if (res == "exist") {
            $(".alert-danger .notification").html("This survey page already exist!");
            $(".alert-danger").addClass("alert-active");
            setTimeout(function () {
              $(".alert-danger").removeClass("alert-active");
            }, 2000);
          }
        }
      });
    } else {
      $(".alert-danger .notification").html("Please input survey page header name!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2000);
    }
  });

  // Update
  $("#update_page").on("click", function () {
    var sc_id = window.localStorage.getItem("sc_id");
    var update_sp_id = window.localStorage.getItem("update_sp_id");
    var tr_id = $("#surveyPages_table .table-active").attr("id");
    if ($("#sp_header_user").html() != "" && $("#surveyPages_table tr").hasClass("table-active") == true) {
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "update_surveyPage",
          update_sp_id: update_sp_id,
          sp_code_name: $("#sp_name_search").val(),
          sp_level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
          sp_name_admin: $("#sp_name_admin").val(),
          sp_description: $("#sp_description").val(),
          sp_currency: $(".currency_format .btn-warning").html(),
          sp_separate: $(".separate_format .btn-warning").attr("id"),
          sp_decimal: $(".decimal_format .btn-warning").html(),
          sp_unit: $("#sp_unit").val(),
          sp_header_user: $("#sp_header_user").html(),
          sp_tagline_user: $("#sp_tagline_user").html(),
          sc_id: sc_id
        },
        async: false,
        success: function (res) {
          if (res == "success") {
            $.fn.init_surveyPage_table();
            $.fn.update_template_value(tr_id);
            $(".alert-success .notification").html("Successfully updated!");
            $(".alert-success").addClass("alert-active");
            setTimeout(function () {
              $(".alert-success").removeClass("alert-active");
            }, 2000);
          }
        }
      });
    } else {
      $(".alert-danger .notification").html("Please input survey page header name!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2000);
    }
  });

  // Change the value on template table
  $("#template").on("keyup", function (e) {
    if ($(e.target).hasClass("total-value") == true) {
      if ((e.keyCode == 8 || e.keyCode == 9 || e.keyCode == 13 || e.keyCode == 46 || e.keyCode == 110 || e.keyCode == 190 || e.keyCode >= 35 && e.keyCode <= 40) || (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)) {
        var value_sum = 0;
        for (var i = 0; i < $("#template tbody tr").length; i++) {
          var change_value = (Number($(e.target).html().replace(",", "")) * Number($("#template tbody tr:eq(" + i + ")").find(".percentage").html().replace(",", ""))).toFixed(2);
          $("#template tbody tr:eq(" + i + ")").find(".value").html(change_value);
          value_sum += Number(change_value);
        }
        $("#template tfoot .value").html((Number($(e.target).html().replace(",", "")) - value_sum).toFixed(2));
      } else {
        $(".alert-danger .notification").html("Please input only number!");
        $(".alert-danger").addClass("alert-active");
        setTimeout(function () {
          $(".alert-danger").removeClass("alert-active");
        }, 2000);
      }
    } else if ($(e.target).hasClass("value") == true) {
      if ((e.keyCode == 8 || e.keyCode == 9 || e.keyCode == 13 || e.keyCode == 46 || e.keyCode == 110 || e.keyCode == 190 || e.keyCode >= 35 && e.keyCode <= 40) || (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)) {
        if (Number($(e.target).html().replace(",", "")) > Number($("#template tfoot .value").html().replace(",", ""))) {
          $(".alert-danger .notification").html("The sum of the values can never greater than total value!");
          $(".alert-danger").addClass("alert-active");
          setTimeout(function () {
            $(".alert-danger").removeClass("alert-active");
          }, 2000);
        } else {
          var percentage = (Number($(e.target).html().replace(",", "")) / Number($("#template .total-value").html().replace(",", ""))).toFixed(10);
          if ($(e.target).siblings().hasClass("percentage") == true) {
            $(e.target).siblings(".percentage").html(percentage);
            var value_sum = 0;
            var percentage_sum = 0;
            for (var i = 0; i < $("#template tbody tr").length; i++) {
              value_sum += Number($("#template tbody tr:eq(" + i + ")").find(".value").html().replace(",", ""));
              percentage_sum += Number($("#template tbody tr:eq(" + i + ")").find(".percentage").html().replace(",", ""));
            }
            $("#template tfoot .value").html(Number($("#template .total-value").html().replace(",", "")) - value_sum);
            $("#template tfoot .sub-percentage").html(1 - percentage_sum);
          }
        }
      } else {
        $(".alert-danger .notification").html("Please input only number!");
        $(".alert-danger").addClass("alert-active");
        setTimeout(function () {
          $(".alert-danger").removeClass("alert-active");
        }, 2000);
      }
    } else if ($(e.target).hasClass("percentage") == true) {
      if ((e.keyCode == 8 || e.keyCode == 9 || e.keyCode == 13 || e.keyCode == 46 || e.keyCode == 110 || e.keyCode == 190 || e.keyCode >= 35 && e.keyCode <= 40) || (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)) {
        if (Number($(e.target).html()) > Number($("#template tfoot .sub-percentage").html())) {
          $(".alert-danger .notification").html("The sum of the percentages can never greater than 1!");
          $(".alert-danger").addClass("alert-active");
          setTimeout(function () {
            $(".alert-danger").removeClass("alert-active");
          }, 2000);
        } else {
          var value = (Number($(e.target).html().replace(",", "")) * Number($("#template .total-value").html().replace(",", "")));
          if ($(e.target).siblings().hasClass("value") == true) {
            $(e.target).siblings(".value").html(value.toFixed(2));
            var value_sum = 0;
            var percentage_sum = 0;
            for (var i = 0; i < $("#template tbody tr").length; i++) {
              value_sum += Number($("#template tbody tr:eq(" + i + ")").find(".value").html().replace(",", ""));
              percentage_sum += Number($("#template tbody tr:eq(" + i + ")").find(".percentage").html().replace(",", ""));
            }
            $("#template tfoot .value").html((Number($("#template .total-value").html().replace(",", "")) - value_sum).toFixed(2));
            $("#template tfoot .sub-percentage").html((1 - percentage_sum).toFixed(10));
          }
        }
      } else {
        $(".alert-danger .notification").html("Please input only number!");
        $(".alert-danger").addClass("alert-active");
        setTimeout(function () {
          $(".alert-danger").removeClass("alert-active");
        }, 2000);
      }
    }
    // Auto Numeric
    new AutoNumeric.multiple('.value', {
      currencySymbol: "",
      caretPositionOnFocus: "start",
      modifyValueOnWheel: false,
      decimalCharacter: separate_format,
      digitGroupSeparator: group_separate,
      decimalPlaces: decimal_format
    });
    new AutoNumeric('.total-value', {
      currencySymbol: "",
      caretPositionOnFocus: "start",
      modifyValueOnWheel: false,
      decimalCharacter: separate_format,
      digitGroupSeparator: group_separate,
      decimalPlaces: decimal_format
    });
  });

  // When click preview button
  $.fn.surveypage_load = function () {
    if ($("sp_name_hidden").val() != "") {
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "surveypage_load",
          sp_id: $("#sp_hidden_temp").val(),
          level_id: $(".sp-level-btn-group .btn-warning").attr("value")
        },
        success: function (res) {
          var template_data = $.fn.display_template(res);
          var separate_format;
          var group_separate;
          if ($(".separate_format btn-warning").attr("id") == "dot") {
            separate_format = ",";
            group_separate = ".";
          } else {
            separate_format = ".";
            group_separate = ",";
          }
          for (x in value_arr) {
            $(".value:eq(" + x + ")").html(value_arr[x]);
          }
          $("#template").html(template_data);
          new AutoNumeric.multiple('.value', {
            currencySymbol: "",
            caretPositionOnFocus: "start",
            modifyValueOnWheel: false,
            decimalCharacter: separate_format,
            digitGroupSeparator: group_separate,
            decimalPlaces: 2
          });
          new AutoNumeric('.total-value', {
            currencySymbol: "",
            caretPositionOnFocus: "start",
            modifyValueOnWheel: false,
            decimalCharacter: separate_format,
            digitGroupSeparator: group_separate,
            decimalPlaces: 2
          });
        }
      });
    } else {
      $(".alert-danger .notification").html("Don't exist the defined data!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2500);
    }
  }

  // Preview button click
  $("#preview").on("click", function () {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: "POST",
      data: {
        type: "preview",
        keyword: $("#sp_level1_search").val()
      },
      success: function (res) {
        $("#template").html($.fn.display_template(res));
        // Auto Numeric
        new AutoNumeric.multiple('.value', {
          currencySymbol: "",
          caretPositionOnFocus: "start",
          modifyValueOnWheel: false,
          decimalCharacter: separate_format,
          digitGroupSeparator: group_separate,
          decimalPlaces: decimal_format
        });
        new AutoNumeric('.total-value', {
          currencySymbol: "",
          caretPositionOnFocus: "start",
          modifyValueOnWheel: false,
          decimalCharacter: separate_format,
          digitGroupSeparator: group_separate,
          decimalPlaces: decimal_format
        });
      }
    });
  });

  // Load as survey page
  $("#load_as_sp").on("click", function () {
    window.localStorage.setItem("template_selected", true);
    $(".alert-success .notification").html("Template is added as survey page!");
    $(".alert-success").addClass("alert-active");
    setTimeout(function () {
      $(".alert-success").removeClass("alert-active");
    }, 2000);
  });

  // When click summary
  $("#results_summary").on("click", function () {
    if ($("#surveyPages_table tr").hasClass("table-active") == true) {
      $.ajax({
        url: "model/pages/surveyPages_model.php",
        type: "POST",
        data: {
          type: "results_summary",
          tr_id: $("#surveyPages_table .table-active").attr("id"),
          sc_id: window.localStorage.getItem("sc_id"),
          level_id: $(".sp-level-btn-group .btn-warning").attr("value"),
          value: $("#template thead").find(".total-value").html().replace(",", ""),
          category_id: $("#template thead").children("tr").attr("id")
        },
        success: function (res) {
          if (res == "success") {
            $(".alert-success .notification").html("Successfully saved!");
            $(".alert-success").addClass("alert-active");
            setTimeout(function () {
              $(".alert-success").removeClass("alert-active");
            }, 2000);
          }
        }
      });
    } else {
      $(".alert-danger .notification").html("Please select a survey!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2000);
    }
  });

  //   **************************************************** Auth Numeric define *******************************************
  var separate_format;
  var group_separate;
  var decimal_format = 2;
  if ($(".separate_format .btn-warning").attr("id") == "comma") {
    group_separate = ",";
    separate_format = ".";
  } else {
    group_separate = ".";
    separate_format = ",";
  }
  //  Select Currency format
  $(".currency_format button").on("click", function () {
    $(".currency_format button").removeClass("btn-warning");
    $(".currency_format button").addClass("btn-outline-warning");
    $(this).addClass("btn-warning");
    $(this).removeClass("btn-outline-warning");
    $(".sp_current").html($(this).attr("value"));
  });

  //  Select page separator
  $(".separate_format button").on("click", function () {
    $(".separate_format button").removeClass("btn-warning");
    $(".separate_format button").addClass("btn-outline-warning");
    $(this).addClass("btn-warning");
    $(this).removeClass("btn-outline-warning");
    if ($(this).attr("id") == "comma") {
      for (x in value_arr) {
        $(".value:eq(" + x + ")").html(value_arr[x]);
      }
      separate_format = ".";
      group_separate = ",";
      new AutoNumeric.multiple('.value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: separate_format,
        digitGroupSeparator: group_separate,
        decimalPlaces: decimal_format
      });
      new AutoNumeric('.total-value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: separate_format,
        digitGroupSeparator: group_separate,
        decimalPlaces: decimal_format
      });
    }
    if ($(this).attr("id") == "dot") {
      for (x in value_arr) {
        $(".value:eq(" + x + ")").html(value_arr[x]);
      }
      separate_format = ",";
      group_separate = ".";
      new AutoNumeric.multiple('.value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: separate_format,
        digitGroupSeparator: group_separate,
        decimalPlaces: decimal_format
      });
      new AutoNumeric('.total-value', {
        currencySymbol: "",
        caretPositionOnFocus: "start",
        modifyValueOnWheel: false,
        decimalCharacter: separate_format,
        digitGroupSeparator: group_separate,
        decimalPlaces: decimal_format
      });
    }
  });

  //  Decimal format
  $(".decimal_format button").on("click", function () {
    $(".decimal_format button").removeClass("btn-warning");
    $(".decimal_format button").addClass("btn-outline-warning");
    $(this).addClass("btn-warning");
    $(this).removeClass("btn-outline-warning");
    decimal_format = Number($(this).html());
    $("#template .value").html().replace(",","");
    $("#template .total-value").html().replace(",","");
    new AutoNumeric.multiple('.value', {
      currencySymbol: "",
      caretPositionOnFocus: "start",
      modifyValueOnWheel: false,
      decimalCharacter: separate_format,
      digitGroupSeparator: group_separate,
      decimalPlaces: decimal_format
    });
    new AutoNumeric('.total-value', {
      currencySymbol: "",
      caretPositionOnFocus: "start",
      modifyValueOnWheel: false,
      decimalCharacter: separate_format,
      digitGroupSeparator: group_separate,
      decimalPlaces: decimal_format
    });
  })

  // Auto Numeric
  new AutoNumeric.multiple('.value', {
    currencySymbol: "",
    caretPositionOnFocus: "start",
    modifyValueOnWheel: false,
    decimalCharacter: separate_format,
    digitGroupSeparator: group_separate,
    decimalPlaces: decimal_format
  });


  // When click the row on surveyPage Table
  var l_c_data = []; // Level category Data 
  $("#surveyPages_table tbody").on("click", function (e) {
    $("#surveyPages_table tbody tr").removeClass("table-active");
    $(e.target).parents("tr").addClass("table-active");
    var tr_id = $("#surveyPages_table .table-active").attr("id");
    window.localStorage.setItem("update_sp_id", tr_id);
    // saved_flag = true;
    $.fn.display_survey_page_table(tr_id);
  });

  // Level name Search
  $("#sp_name_search").on("keyup", function () {
    var l_c_name = "";
    var key = new RegExp($("#sp_name_search").val(), 'i');
    $("#level_name_list").removeClass("d-none");
    for (x in l_c_data) {
      if (l_c_data[x]["name"].search(key) > -1) {
        l_c_name += "<div class='px-3 py-1' id='" + l_c_data[x]["id"] + "'>" + l_c_data[x]["name"] + "</div>";
      }
    }
    $("#level_name_list").html(l_c_name);
  });

  $("#level_name_list").on("click", function (e) {
    if ($(e.target).parent().attr("id") == "level_name_list") {
      $("#sp_name_search").val($(e.target).html());
      window.localStorage.setItem("sp_ct_id", $(e.target).attr("id"));
      $("#level_name_list").addClass("d-none");
    }
  });

  $("#level_name_list").on("mouseleave", function () {
    $(this).addClass("d-none");
  })

  // ***************************************************** User define *************************************************** 
  // Survey page table move row
  $(".sp_tbody").sortable({
    delay: 150,
    stop: function () {
      var selectedData = new Array();
      $('.sp_tbody>tr').each(function () {
        selectedData.push($(this).attr("id"));
      });
      $.fn.sp_updateOrder(selectedData);
    }
  });
  $.fn.sp_updateOrder = function (data) {
    $.ajax({
      url: "model/pages/surveyPages_model.php",
      type: 'POST',
      data: {
        type: "sp_table_row",
        level_id: $("sp-level-btn-group .btn-warning").attr("value"),
        position: data
      },
      async: false,
      success: function (res) {
        if (res == "success") {
          $(".alert-success .notification").html("Successfully Changed!");
          $(".alert-success").addClass("alert-active");
          setTimeout(function () {
            $(".alert-success").removeClass("alert-active");
          }, 2000);
          $.fn.init_surveyPage_table();
        }
      }
    });
  }

  $("#file").on("change", function () {
    $("#template_icon_name").html($("#file")[0].files[0].name);
  });

  $(".modal input[type=text]").on("change", function(){
    $(".modal input[type=text]").css("border-color", "gray");
  });

  $("#new_percentage").on("keypress", function(){
    $(".new_percentage_notification").html("");
  });
  //  Icon Upload
  var file;
  var fdata = new FormData();
  $("#sp_add_data").on("click", function () {
    if ($("#new_name").val() == "" || $("#new_code").val() == "" || $("#new_percentage").val() == "") {
      for (var i = 0; i < $("input[type=text]").length; i++) {
        if ($("input[type=text]").eq(i).val() == "") {
          $("input[type=text]").eq(i).css("border-color", "red");
        }
      }
    } else if ($("#surveyPages_table tr").hasClass("table-active") == true) {
      if (Number($("#new_percentage").val()) > Number($(".sub-percentage").html())) {
        $(".new_percentage_notification").html("The current percentage can not be greater than " + Number($(".sub-percentage").html()));
      } else {
        var total_temp = $("#template thead").find(".total-value").html();
        if ($("#comma").hasClass("btn-warning") == true) {
          total_temp = total_temp.replace(",", "");
        } else {
          total_temp = total_temp.replace(",", "");
        }
        var new_value = Number(total_temp) * Number($("#new_percentage").val());
        var sub_percentage = Number($(".sub-percentage").html()) - Number($("#new_percentage").val());
        var sub_value = Number(total_temp) * sub_percentage;
        var sub_order = Number($("#template tbody tr").length) + 2;
        var level_id = $(".sp-level-btn-group .btn-warning").attr("value");
        var template_id = $("#sp_level1_search").val();
        file = $("#file")[0].files[0];
        fdata.append("file", file);
        fdata.append("name", $("#new_name").val());
        fdata.append("percentage", $("#new_percentage").val());
        fdata.append("code", $("#new_code").val());
        fdata.append("value", new_value)
        fdata.append("order", Number($("#template tbody tr").length));
        fdata.append("sub_percentage", sub_percentage);
        fdata.append("sub_value", sub_value);
        fdata.append("sub_order", sub_order);
        fdata.append("sub_id", Number($(".sub-percentage").parent().attr("id")));
        fdata.append("level_id", level_id);
        fdata.append("surveylogin_id", window.localStorage.getItem("surveylogin_id"));
        fdata.append("surveycode_id", window.localStorage.getItem("surveycode_id"));
        fdata.append("template_id", template_id);
        fdata.append("sp_order_id", window.localStorage.getItem("update_sp_id"));
        $.ajax({
          url: "model/pages/upload.php",
          type: "POST",
          data: fdata,
          processData: false,
          contentType: false,
          dataType: "text",
          async: false,
          success: function (res) {
            if (res == "success") {
              if ($("#surveyPages_table tr").hasClass("table-active") == true) {
                var tr_id = $("#surveyPages_table .table-active").attr("id");
                window.localStorage.setItem("update_sp_id", tr_id);
                $.fn.display_survey_page_table(tr_id);
                $(".modal .close").click();
                $(".modal-backdrop").remove();
              }
            }
          }
        });
      }
    } else {
      $(".alert-danger .notification").html("Please select survey on above table!");
      $(".alert-danger").addClass("alert-active");
      setTimeout(function () {
        $(".alert-danger").removeClass("alert-active");
      }, 2000);
    }
  });

  // When click New Page Button
  $("#sp_new").on("click", function () {
    $("#surveyPages_table tr").removeClass("table-active");
    window.localStorage.removeItem("update_sp_id");
    $("#sp_name_search").val("");
    $("#sp_name_admin").val("");
    $("#sp_description").val("");
    $("#sp_unit").val("");
    $("#sp_header_user").html("");
    $("#sp_tagline_user").html("");
    $("#currency_format button").removeClass("btn-warning");
    $("#currency_format button").addClass("btn-outline-warning");
    $("#currency_format button:eq(0)").addClass("btn-warning");
    $("#currency_format button:eq(0)").removeClass("btn-outline-warning");
    $("#separate_format button").removeClass("btn-warning");
    $("#separate_format button").addClass("btn-outline-warning");
    $("#separate_format #comma").addClass("btn-warning");
    $("#separate_format #comma").removeClass("btn-outline-warning");
    $("#decimal_format button").removeClass("btn-warning");
    $("#decimal_format button").addClass("btn-outline-warning");
    $("#decimal_format #dc_2").addClass("btn-warning");
    $("#decimal_format #dc_2").removeClass("btn-outline-warning");
  });

});