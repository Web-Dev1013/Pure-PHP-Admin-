$(".message-update").on("click", function(e){
    var message_title = $(e.target).parents(".message-body").find(".message-title").html();
    var message_content = $(e.target).parents(".message-body").find(".message-content").html();
    var email = window.localStorage.getItem("user_email");
    $.ajax({
        url: "model/pages/message_model.php",
        type: "POST",
        data: {
            type: "save_message",
            title: message_title,
            content: message_content,
            email: email
        },
        success: function(res){
            console.log(res);
        }
    })
});