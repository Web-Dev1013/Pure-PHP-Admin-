    $(function () {
        $("#login").on("click", function () {
            if ($("#username").val() != "" && $("#password").val() != "") {
                var username = $("#username").val();
                var password = $("#password").val();
                $.ajax({
                    url: "model/auth/auth_model.php",
                    type: "POST",
                    data: {
                        type: "login",
                        username: username,
                        password: password
                    },
                    success: function (res) {
                        if (res == "success") {
                            $(".alert-success .notification").html("Successfully Login.");
                            $(".alert-success").addClass("alert-active");
                            setTimeout(function () {
                                $(".alert-danger").removeClass("alert-active");
                                window.location.href = "index.php";
                            }, 1500);
                        } else if (res == "failed") {
                            $(".alert-danger .notification").html("No registered user.");
                            $(".alert-danger").addClass("alert-active");
                            setTimeout(function () {
                                $(".alert-danger").removeClass("alert-active");
                            }, 1500);
                        }
                    }
                });
            }
        });
    })