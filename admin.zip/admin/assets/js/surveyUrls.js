var url_table = $('#url_table').DataTable({
  "filter": false,
  "info": false,
  "data": [],
  "columns": [{
      "title": "Username",
      "data": 'email'
    },
    {
      "title": "CodeName",
      "data": 'sc_name'
    },
    {
      "title": "Code",
      "data": 'sc_hash'
    },
    {
      "title": "Pages",
      "data": 'pages'
    },
    {
      "title": "+Page",
      "data": 'page'
    },
    {
      "title": "Responses",
      "data": 'responses'
    },
    {
      "title": "Expires In",
      "data": 'expire'
    },
    {
      "title": "Generate URL",
      "data": 'generate'
    }
  ]
});
$(".dataTables_paginate.paging_simple_numbers").addClass("float-right mb-2");
$("#url_table_length").hide();
$("#url_table_length select").addClass("form-control mx-auto w-50 border-warning text-gold font-weight-bold");

//  ***************************************** User define function *******************************************************
$.fn.init_url_table = function (user_email) {
  $.ajax({
    url: "model/pages/surveyUrl_model.php",
    type: "POST",
    data: {
      type: "init_url_table",
      user_email: user_email
    },
    success: function (res) {
      res = JSON.parse(res);
      url_table.clear();
      $.each(res, function (index, value) {
        var rowIndex = url_table.row.add(value);
        var row = $('#url_table').dataTable().fnGetNodes(rowIndex);
        $(row).attr('id', res[index]["id"]);
      });
      url_table.draw();
      var option = "";
      for (x in res) {
        option += "<option value='" + res[x]["id"] + "'>" + res[x]["sc_name"] + "</option>";
      }
      $("#url_search").html(option);
      $("#url_search").select2();
    }
  });
}

$.fn.get_url = function (tr_id) {
  $("#url_table tbody tr").removeClass("table-active");
  $("#url_table #" + tr_id).addClass("table-active");
  $.ajax({
    url: "model/pages/surveyUrl_model.php",
    type: "POST",
    data: {
      type: "get_url",
      tr_id: tr_id
    },
    success: function (res) {
      res = JSON.parse(res);
      var url = "https://localhost/admin/?un=" + res["username_hash"] + "&pw=" + res["password_hash"] + "&ac=" + res["sc_hash"];
      $("#url").val(url);
    }
  });
}

//  Init url table
$("#url_item").on("click", function () {
  var user_email = window.localStorage.getItem("user_email");
  if (user_email == null) {
    $(".alert-danger .notification").html("No user selected! Please select user.");
    $(".alert-danger").addClass("alert-active");
    setTimeout(function () {
      $(".alert-danger").removeClass("alert-active");
    }, 2000);
  } else {
    $.fn.init_url_table(user_email);
  }
});

// Select Url
$("#url_search").on("change", function () {
  var tr_id = $("#url_search").val();
  $.fn.get_url(tr_id);
});

// Copy Link
$("#copy_url").on("click", function () {
  if (tr_id == "") {
    $(".alert-danger .notification").html("Please select survey code.");
    $(".alert-danger").addClass("alert-active");
    setTimeout(function () {
      $(".alert-danger").removeClass("alert-active");
    }, 2000);
  } else {
    var copyText = document.getElementById("url");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    $(".alert-success .notification").html("Survey code copied to clipboard.");
    $(".alert-success").addClass("alert-active");
    setTimeout(function () {
      $(".alert-success").removeClass("alert-active");
    }, 2000);
  }
});

var tr_id;
$("#url_table tbody").on("click", function (e) {
  tr_id = $(e.target).parent("tr").attr("id");
  $.fn.get_url(tr_id);
});