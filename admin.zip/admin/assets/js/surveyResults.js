var results_table = $('#results_table').DataTable({
  "paginate": true,
  "filter": false,
  "info": false,
  "data": [],
  "columns": [{
      "title": "User",
      "data": 'user_email'
    },
    {
      "title": "SurveyCode",
      "data": 'sc_hash'
    },
    {
      "title": "Survey_code_name",
      "data": 'sc_name'
    },
    {
      "title": "Survey_page_header",
      "data": 'sp_header'
    },
    {
      "title": "Page_display_order_user",
      "data": 'page_order'
    }
  ]
});
$(".dataTables_paginate.paging_simple_numbers").addClass("float-right mb-2");
$("#results_table_length").hide();
$("#results_table_length select").addClass("form-control mx-auto w-50 border-warning text-gold font-weight-bold");

//   Init Survey result table
$.fn.init_surveyResults_table = function () {
  $.ajax({
    url: "model/pages/surveyResults_model.php",
    type: "POST",
    data: {
      type: "init_surveyResults_table",
      sc_id: window.localStorage.getItem("sc_id"),
      user_email: window.localStorage.getItem("user_email")
    },
    success: function (res) {
      var data = [];
      var order = 0;
      res = JSON.parse(res);
      for (x in res) {
        for (n in res[x]) {
          order++;
          res[x][n]["page_order"] = order;
          data.push(res[x][n]);
        }
      }
      results_table.clear();
      $.each(data, function (index, value) {
        var row_data = results_table.row.add(value);
        var row = $("#results_table").dataTable().fnGetNodes(row_data);
        $(row).attr("id", data[index]["id"]);
      });
      results_table.draw();
      var option_data = "";
      for (x in data) {
        option_data += "<option value='" + data[x]["id"] + "'>" + data[x]["sp_header"] + "</option>";
      }
      $("#results_search").html(option_data);
      $("#results_search").select2({
        placeholder: "Select results..."
      });
    }
  });
}

$("#result_item").on("click", function () {
  if (window.localStorage.getItem("sc_id") == null) {
    $(".alert-danger .notification").html("Please select survey code!");
    $(".alert-danger").addClass("alert-active");
    setTimeout(function () {
      $(".alert-danger").removeClass("alert-active");
    }, 2500);
  } else {
    $.fn.init_surveyResults_table();
  }
});