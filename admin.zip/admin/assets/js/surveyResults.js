var results_table = $('#results_table').DataTable({
  "paginate": true,
  "filter": false,
  "info": false,
  "data": [],
  "columns": [{
      "title": "User",
      "data": 'user'
    },
    {
      "title": "SurveyCode",
      "data": 'survey_code'
    },
    {
      "title": "Survey_code_name",
      "data": 'sc_name'
    },
    {
      "title": "Survey_page_header",
      "data": 'sp_header'
    },
    {
      "title": "Page_display_order_user",
      "data": 'page_order'
    }
  ]
});
$(".dataTables_paginate.paging_simple_numbers").addClass("float-right mb-2");
$("#results_table_length").hide();
$("#results_table_length select").addClass("form-control mx-auto w-50 border-warning text-gold font-weight-bold");

//   Init Survey result table
$.fn.init_surveyResults_table = function () {
  $.ajax({
    url: "model/surveyResults_model.php",
    type: "POST",
    data: {
      type: "init_surveyResults_table",
      sc_id: window.localStorage.getItem("sc_id"),
      user_email: window.localStorage.getItem("user_email")
    },
    success: function (res) {
      console.log(res);
    }
  });
}

$("#result_item").on("click", function(){
  $.fn.init_surveyResults_table();
});