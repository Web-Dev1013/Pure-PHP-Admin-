<?php
session_start();

include("../../common/env.php");
$db_host = getenv("DB_HOST");
$db_username = getenv("DB_USERNAME");
$db_password = getenv("DB_PASSWORD");
$db_name = getenv("DB_NAME");

$conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_username, $db_password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if($_POST["type"] == "save_message"){
    $email = $_POST["email"];
    $title = $_POST["title"];
    $content = $_POST["content"];
    $date_time = date("Y:m:d h:i:s");
    try{
        $user_info = $conn->prepare("SELECT first_name, last_name, phone_number FROM `user` WHERE email = '$email'");
        $user_info->execute();
        if($user_info->rowCount() > 0){
            $user_info_temp = $user_info->fetchAll();
            foreach($user_info_temp as $temp){
                $name = $temp["first_name"].$temp["last_name"];
                $phone = $temp["phone_number"];
            }
            $message_data = $conn->prepare("INSERT INTO `messages` SET `name`='$name', `subject`='$title', email='$email', phone='$phone', `message`='$content', created_at='$date_time'");
            $message_data->execute();
            echo "success";
        }
    }catch(PDOException $e){
        echo "failed".$e->getMessage();
    }
}