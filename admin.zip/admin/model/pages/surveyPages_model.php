<?php
session_start();

include("../../common/env.php");
$db_host = getenv("DB_HOST");
$db_username = getenv("DB_USERNAME");
$db_password = getenv("DB_PASSWORD");
$db_name = getenv("DB_NAME");

$conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_username, $db_password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* --------------------------------------------- Init Define -------------------------------------------------------*/
// Init templates
if ($_POST["type"] == "init_template") {
  $level_id = 1;
  $sp_header_user = "Holiday Expenditure";
  if ($_POST["sp_header_user"] != "none") {
    $level_id = $_POST["level_id"];
    $sc_id = $_POST["sc_id"];
    $sp_header_user = $_POST["sp_header_user"];
  }
  $customcategories = "level" . $level_id . "customcategories";
  $surveypages = "level" . $level_id . "surveypages";
  $customcategories_template_id = "level" . $level_id . "customcategories_template_id";
  $templates_data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT a.survey_page_unit AS unit, a.survey_page_currency AS currency, c.* FROM $surveypages AS a
    LEFT JOIN surveycode AS b ON b.id = a.survey_code_id
    LEFT JOIN $customcategories AS c ON c.base_template_id = a.$customcategories_template_id
    WHERE a.survey_page_header_user = '$sp_header_user'
    ORDER BY c.order");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $templates_data[$i]["id"] = $temp["id"];
        $templates_data[$i]["icon_url"] = $temp["icon_url"];
        $templates_data[$i]["category_code"] = $temp["category_code"];
        $templates_data[$i]["name"] = $temp["name"];
        $templates_data[$i]["value"] = $temp["value_load"];
        $templates_data[$i]["percentage"] = $temp["percentage"];
        $templates_data[$i]["flag_id"] = $temp["flag_id"];
        $templates_data[$i]["unit"] = $temp["unit"];
        $templates_data[$i]["currency"] = $temp["currency"];
        $i++;
      }
      echo json_encode($templates_data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Survey page load
if ($_POST["type"] == "surveypage_load") {
  $sp_id = $_POST["sp_id"];
  $level_id = $_POST["level_id"];
  $customcategories = "level" . $level_id . "customcategories";
  $surveypages = "level" . $level_id . "surveypages";
  $customcategories_template_id = "level" . $level_id . "customcategories_template_id";
  $templates_data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT a.*, b.survey_page_unit as unit FROM $customcategories AS a
    LEFT JOIN $surveypages AS b ON b.survey_code_id = a.survey_code_id AND b.$customcategories_template_id = a.base_template_id
    WHERE b.id = '$sp_id'
    ORDER BY a.order");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $templates_data[$i]["id"] = $temp["id"];
        $templates_data[$i]["icon_url"] = $temp["icon_url"];
        $templates_data[$i]["category_code"] = $temp["category_code"];
        $templates_data[$i]["name"] = $temp["name"];
        $templates_data[$i]["value"] = $temp["value_load"];
        $templates_data[$i]["percentage"] = $temp["percentage"];
        $templates_data[$i]["flag_id"] = $temp["flag_id"];
        $templates_data[$i]["unit"] = $temp["unit"];
        $i++;
      }
      echo json_encode($templates_data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

//  When move the row in survey table
if ($_POST["type"] == "sp_table_row") {
  $position = $_POST["position"];
  try {
    foreach ($position as $k => $v) {
      $stmt = $conn->prepare("UPDATE surveypageorder SET `order`='$k' WHERE id='$v'");
      $stmt->execute();
    }
    echo "success";
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

//  When move the row in template table
if ($_POST["type"] == "move_row") {
  $position = $_POST["position"];
  try {
    foreach ($position as $k => $v) {
      $stmt = $conn->prepare("UPDATE basecategories SET `order`='$k' WHERE id='$v'");
      $stmt->execute();
    }
    echo "success";
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Init surveyPage Table
if ($_POST["type"] == "init_surveyPage_table") {
  $sc_id = $_POST["sc_id"];
  $table_data = array();
  $i = 0;
  try {
    $level = $conn->prepare("SELECT b.level_id FROM surveycode AS a
        LEFT JOIN surveylogin AS b ON a.survey_login_id = b.id
        WHERE a.id = '$sc_id'");
    $level->execute();
    if ($level->rowCount() > 0) {
      $level_result = $level->fetchAll();
      foreach ($level_result as $temp) {
        $level_result = $temp["level_id"];
      }
      $surveypage_table_name = "level" . $level_result . "surveypages";
      $stmt = $conn->prepare("SELECT a.id, e.email AS `user`, b.survey_code_name AS codeName, b.survey_code_hash AS codeHash, c.survey_page_header_user AS pageHeader, c.page_display_order_user AS pageOrder FROM surveypageorder AS a
            LEFT JOIN surveycode AS b ON a.surveycode_id=b.id
            LEFT JOIN $surveypage_table_name AS c ON c.id=a.surveypage_id
            LEFT JOIN surveylogin AS d ON b.survey_login_id=d.id
            LEFT JOIN `user` AS e ON d.user_id=e.id
            WHERE b.id = '$sc_id'
            ORDER BY a.order");
      $stmt->execute();
      if ($stmt->rowCount() > 0) {
        $result = $stmt->fetchAll();
        foreach ($result as $key => $temp) {
          $table_data[$i]["id"] = $temp["id"];
          $table_data[$i]["user"] = $temp["user"];
          $table_data[$i]["codeHash"] = $temp["codeHash"];
          $table_data[$i]["codeName"] = $temp["codeName"];
          $table_data[$i]["pageHeader"] = $temp["pageHeader"];
          $table_data[$i]["pageOrder"] = $key + 1;
          $i++;
        }
        echo json_encode($table_data);
      }
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// SurveyPages base data
if ($_POST["type"] == "sp_base_data") {
  $sc_id = $_POST["sc_id"];
  $data = array();
  try {
    $stmt = $conn->prepare("SELECT b.* FROM surveycode AS a 
        LEFT JOIN surveylogin AS b ON a.survey_login_id = b.id
        WHERE a.id = '$sc_id'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $data["surveyed_co_id"] = $temp["surveyed_co_id"];
        $data["purchased_co_id"] = $temp["purchased_co_id"];
        $data["area"] = $temp["area"];
        $data["financial_year"] = $temp["financial_year"];
        $data["fiscal_year_ends"] = $temp["fiscal_year_ends"];
        $data["month_start"] = $temp["month_start"];
        $data["month_end"] = $temp["month_end"];
        $data["period_id"] = $temp["period_id"];
        $data["level_id"] = $temp["level_id"];
      }
      echo json_encode($data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Init Period dropdown
if ($_POST["type"] == "init_period") {
  echo $_SESSION["period"];
}

// Init company dropdown
if ($_POST["type"] == "init_company") {
  $company_data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT id, `name` from company");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $company_data[$i]["id"] = $temp["id"];
        $company_data[$i]["name"] = $temp["name"];
        $i++;
      }
      echo json_encode($company_data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Add new survey page
if ($_POST["type"] == "save_surveyPage") {
  $sc_id = $_POST["sc_id"];
  $sp_name = $_POST["sp_name"];
  $sp_level_id = $_POST["sp_level_id"];
  $sp_template_id = $_POST["sp_template_id"];
  $sp_name_admin = $_POST["sp_name_admin"];
  $sp_description = $_POST["sp_description"];
  $sp_currency = $_POST["sp_currency"];
  $sp_separate = $_POST["sp_separate"];
  $sp_decimal = $_POST["sp_decimal"];
  $sp_unit = $_POST["sp_unit"];
  $sp_header_user = $_POST["sp_header_user"];
  $sp_tagline_user = $_POST["sp_tagline_user"];
  $date = date_create();
  $time = date_timestamp_get($date);
  $tablename = "level" . $sp_level_id . "surveypages";
  $customcategories = "level" . $sp_level_id . "customcategories";
  $category_template_id = "level" . $sp_level_id . "customcategories_template_id";
  $customtemplates = "level" . $sp_level_id . "customtemplates";
  try {
    $sp_exist = $conn->prepare("SELECT id FROM $tablename WHERE survey_page_name_admin='$sp_name_admin' AND survey_code_id='$sc_id'");
    $sp_exist->execute();
    if ($sp_exist->rowCount() > 0) {
      echo "exist";
      exit;
    } else {
      $sc_id = $conn->prepare("SELECT id FROM surveycode WHERE id = '$sc_id'");
      $sc_id->execute();
      if ($sc_id->rowCount() > 0) {
        $sc_id_temp = $sc_id->fetchAll();
        foreach ($sc_id_temp as $temp) {
          $sc_id_temp = $temp["id"];
        }
      }
      $sc_survey_page_num = $conn->prepare("SELECT count(id) as num  FROM $tablename WHERE survey_code_id = '$sc_id_temp'");
      $sc_survey_page_num->execute();
      if ($sc_survey_page_num->rowCount() > 0) {
        $sc_survey_page_num = $sc_survey_page_num->fetchAll();
        foreach ($sc_survey_page_num as $temp) {
          $sc_survey_page_num = $temp["num"];
        }
        $sc_survey_page_num = $sc_survey_page_num + 1;
      }
      $stmt = $conn->prepare("INSERT INTO $tablename SET created_at='$time', survey_code_id='$sc_id_temp', survey_page_header_user='$sp_header_user',survey_page_tagline_user = '$sp_tagline_user', $category_template_id = '$sp_template_id',survey_page_name_admin='$sp_name_admin', survey_page_description_admin='$sp_description', survey_page_currency='$sp_currency', survey_page_separator='$sp_separate', survey_page_decimals='$sp_decimal', survey_page_unit='$sp_unit', page_display_order_user = $sc_survey_page_num");
      $stmt->execute();
      $sp_id = $conn->prepare("SELECT id from $tablename where created_at = '$time'");
      $sp_id->execute();
      if ($sp_id->rowCount() > 0) {
        $sp_id_temp = $sp_id->fetchAll();
        foreach ($sp_id_temp as $order_temp) {
          $sp_id_temp = $order_temp["id"];
        }
      }
      $page_order = $conn->prepare("INSERT INTO surveypageorder SET created_at='$time', surveycode_id='$sc_id_temp', surveypage_id='$sp_id_temp', `order`='$sc_survey_page_num'");
      $page_order->execute();
      $sp_bc_data = $conn->prepare("INSERT INTO $customcategories (survey_login_id, survey_code_id, base_template_id, parent_id,`order`, category_code, flag_id, is_result, is_hidden, `percentage`, icon_url, `name`, `help`, `sign`, value_load) 
      SELECT a.survey_login_id, a.id, base_template_id, parent_id,`order`, category_code, flag_id, is_result, is_hidden, `percentage`, icon_url, `name`, `help`, `sign`, value_load FROM basecategories 
      LEFT JOIN surveycode AS a ON a.id='$sc_id_temp'
      WHERE base_template_id='$sp_template_id'");
      $sp_bc_data->execute();
      $sp_templates_data = $conn->prepare("INSERT INTO `level1customtemplates` (surveylogin_id, survey_code_id, mastercategories_category_code, template_name, template_description) 
      SELECT a.survey_login_id, a.id, b.mastercategories_category_code, '$sp_header_user', b.template_description FROM `basetemplates` AS b
      LEFT JOIN surveycode AS a ON a.id='$sc_id_temp'
      WHERE b.id = '$sp_template_id'");
      $sp_templates_data->execute();
      echo "success";
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Update survey page
if ($_POST["type"] == "update_surveyPage") {
  $sc_id = $_POST["sc_id"];
  $update_sp_id = $_POST["update_sp_id"];
  $sp_code_name = $_POST["sp_code_name"];
  $sp_level_id = $_POST["sp_level_id"];
  $sp_name_admin = $_POST["sp_name_admin"];
  $sp_description = $_POST["sp_description"];
  $sp_currency = $_POST["sp_currency"];
  $sp_separate = $_POST["sp_separate"];
  $sp_decimal = $_POST["sp_decimal"];
  $sp_unit = $_POST["sp_unit"];
  $sp_header_user = $_POST["sp_header_user"];
  $sp_tagline_user = $_POST["sp_tagline_user"];
  $date = date_create();
  $time = date_timestamp_get($date);
  $tablename = "level" . $sp_level_id . "surveypages";
  try {
    $sc_id = $conn->prepare("SELECT id FROM surveycode WHERE id = '$sc_id'");
    $sc_id->execute();
    $sc_id_temp;
    if ($sc_id->rowCount() > 0) {
      $sc_id_temp = $sc_id->fetchAll();
      foreach ($sc_id_temp as $temp) {
        $sc_id_temp = $temp["id"];
      }
    }
    $sp_id = $conn->prepare("SELECT surveypage_id FROM surveypageorder WHERE id='$update_sp_id'");
    $sp_id->execute();
    $sp_id_temp;
    if ($sp_id->rowCount() > 0) {
      $sp_id_temp = $sp_id->fetchAll();
      foreach ($sp_id_temp as $sp_temp) {
        $sp_id_temp = $sp_temp["surveypage_id"];
      }
    }
    $stmt = $conn->prepare("UPDATE $tablename SET created_at='$time', survey_code_id='$sc_id_temp', survey_page_header_user='$sp_header_user',survey_page_tagline_user = '$sp_tagline_user', survey_page_name_admin='$sp_name_admin', survey_page_description_admin='$sp_description', survey_page_currency='$sp_currency', survey_page_separator='$sp_separate', survey_page_decimals='$sp_decimal', survey_page_unit='$sp_unit' WHERE id='$sp_id_temp'");
    $stmt->execute();
    $page_order = $conn->prepare("UPDATE surveypageorder SET created_at='$time', surveycode_id='$sc_id_temp' WHERE surveypage_id='$update_sp_id'");
    $page_order->execute();
    echo "success";
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Display selected surveyPages table data
if ($_POST["type"] == "display_selected_surveyPages_data") {
  $tr_id = $_POST["tr_id"];
  $tr_data = array();
  try {
    $stmt = $conn->prepare("SELECT a.*, c.surveycode_id, b.survey_login_id FROM surveylogin AS a
        LEFT JOIN surveycode AS b ON b.survey_login_id = a.id
        LEFT JOIN surveypageorder AS c ON c.surveycode_id = b.id
        WHERE c.id = '$tr_id'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $tr_data["surveyed_co_id"] = $temp["surveyed_co_id"];
        $tr_data["purchased_co_id"] = $temp["purchased_co_id"];
        $tr_data["area"] = $temp["area"];
        $tr_data["financial_year"] = $temp["financial_year"];
        $tr_data["fiscal_year_ends"] = $temp["fiscal_year_ends"];
        $tr_data["month_start"] = $temp["month_start"];
        $tr_data["month_end"] = $temp["month_end"];
        $tr_data["period_id"] = $temp["period_id"];
        $tr_data["level_id"] = $temp["level_id"];
        $tr_data["surveycode_id"] = $temp["surveycode_id"];
        $tr_data["surveylogin_id"] = $temp["survey_login_id"];
      }
      echo json_encode($tr_data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Init base categories name
if ($_POST["type"] == "init_base_categories") {
  $b_c_data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT id, template_name FROM basetemplates");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $b_c_data[$i]["template_name"] = $temp["template_name"];
        $b_c_data[$i]["id"] = $temp["id"];
        $i++;
      }
      echo json_encode($b_c_data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Init level categories name
if ($_POST["type"] == "init_level_categories") {
  $level_id = $_POST["level_id"];
  $tablename = "level" . $level_id . "customcategories";
  $sc_id = $_POST["sc_id"];
  $l_c_data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT a.id, a.template_name FROM level1customtemplates AS a
    WHERE a.survey_code_id = '$sc_id'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $l_c_data[$i]["id"] = $temp["id"];
        $l_c_data[$i]["name"] = $temp["template_name"];
        $i++;
      }
      $_SESSION["level_category"] = json_encode($l_c_data);
      echo json_encode(($l_c_data));
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Search level name
if ($_POST["type"] == "search_level_name") {
  echo $_SESSION["level_category"];
}

// Search Level category Name
if ($_POST["type"] == "level_category_load") {
  $keyword = $_POST["keyword"];
  $level_id = $_POST["level_id"];
  $surveypage_table_name = "level" . $level_id . "surveypages";
  $data = array();
  try {
    $stmt = $conn->prepare("SELECT a.id, a.survey_page_name_admin AS `name`, a.survey_page_description_admin AS `description`, a.survey_page_currency AS currency, a.survey_page_separator AS `separator`, a.survey_page_decimals AS `decimal`, a.survey_page_unit AS unit FROM $surveypage_table_name AS a
    LEFT JOIN level1customtemplates AS b ON b.template_name = a.survey_page_header_user
    WHERE b.id = '$keyword'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $data["id"] = $temp["id"];
        $data["name"] = $temp["name"];
        $data["description"] = $temp["description"];
        $data["currency"] = $temp["currency"];
        $data["separator"] = $temp["separator"];
        $data["decimal"] = $temp["decimal"];
        $data["unit"] = $temp["unit"];
      }
      echo json_encode($data);
    } else {
      echo "no_page";
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Search base template data
if ($_POST["type"] == "preview") {
  $keyword = $_POST["keyword"];
  $data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT a.survey_page_unit AS unit, b.* FROM level1surveypages AS a
        LEFT JOIN basecategories AS b ON b.base_template_id= a.id
        WHERE b.base_template_id = '$keyword'
        ORDER BY b.order");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $data[$i]["id"] = $temp["id"];
        $data[$i]["icon_url"] = $temp["icon_url"];
        $data[$i]["category_code"] = $temp["category_code"];
        $data[$i]["name"] = $temp["name"];
        $data[$i]["value"] = $temp["value_load"];
        $data[$i]["percentage"] = $temp["percentage"];
        $data[$i]["flag_id"] = $temp["flag_id"];
        $data[$i]["unit"] = $temp["unit"];
        $i++;
      }
      echo json_encode($data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// detail_and_formatting_data
if ($_POST["type"] == "detail_and_formatting_data") {
  $tr_id = $_POST["tr_id"];
  $level_id = $_POST["level_id"];
  $tablename = "level" . $level_id . "surveypages";
  $data = array();
  try {
    $stmt = $conn->prepare("SELECT a.* FROM $tablename AS a 
        LEFT JOIN surveypageorder AS b ON b.surveypage_id = a.id
        WHERE b.id = '$tr_id'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $data["survey_page_header_user"] = $temp["survey_page_header_user"];
        $data["survey_page_tagline_user"] = $temp["survey_page_tagline_user"];
        $data["survey_page_name_admin"] = $temp["survey_page_name_admin"];
        $data["survey_page_description_admin"] = $temp["survey_page_description_admin"];
        $data["survey_page_currency"] = $temp["survey_page_currency"];
        $data["survey_page_separator"] = $temp["survey_page_separator"];
        $data["survey_page_unit"] = $temp["survey_page_unit"];
        $data["survey_page_decimals"] = $temp["survey_page_decimals"];
      }
      echo json_encode($data);
    } else {
      echo "failed";
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Template table define
if ($_POST["type"] == "template_table_data") {
  $tr_id = $_POST["tr_id"];
  $level_id = $_POST["level_id"];
  $category_table = "level" . $level_id . "customcategories";
  $surveypage_table = "level" . $level_id . "surveypages";
  $template_id = "level" . $level_id . "customcategories_template_id";
  $data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT a.*, b.survey_page_unit as unit, b.survey_page_currency as currency FROM $category_table AS a
        LEFT JOIN $surveypage_table AS b ON b.$template_id = a.base_template_id
	      LEFT JOIN surveypageorder AS c ON c.surveypage_id = b.id
        WHERE c.id='$tr_id' AND c.surveycode_id = a.survey_code_id
        ORDER BY a.flag_id");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $data[$i]["id"] = $temp["id"];
        $data[$i]["icon_url"] = $temp["icon_url"];
        $data[$i]["category_code"] = $temp["category_code"];
        $data[$i]["name"] = $temp["name"];
        $data[$i]["value"] = $temp["value_load"];
        $data[$i]["percentage"] = $temp["percentage"];
        $data[$i]["flag_id"] = $temp["flag_id"];
        $data[$i]["unit"] = $temp["unit"];
        $data[$i]["currency"] = $temp["currency"];
        $i++;
      }
      echo json_encode($data);
    } else {
      echo "failed";
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// When click Save as template 
if ($_POST["type"] == "save_template_as") {
  $level_id = $_POST["level_id"];
  $sc_id = $_POST["sc_id"];
  $sp_header_user = $_POST["sp_header_user"];
  $sp_bc_id = $_POST["sp_bc_id"];
  $sp_table = "level" . $level_id . "surveypages";
  $sp_customcategories = "level" . $level_id . "customcategories";
  $sp_template_id = "level" . $level_id . "customcategories_template_id";
  try {
    $exist_template = $conn->prepare("SELECT id FROM basetemplates WHERE template_name = '$sp_header_user'");
    $exist_template->execute();
    if ($exist_template->rowCount() > 0) {
      echo "exist";
    } else {
      $templates_data = $conn->prepare("INSERT INTO `basetemplates` (mastercategories_category_code, template_name, template_description) 
    SELECT b.mastercategories_category_code, '$sp_header_user', b.template_description FROM `level1customtemplates` AS b
    LEFT JOIN surveycode AS a ON a.id='$sc_id'
    WHERE b.survey_code_id = a.id AND b.template_name = '$sp_header_user'");
      $templates_data->execute();
      $stmt = $conn->prepare("INSERT INTO basecategories (base_template_id, parent_id,`order`,flag_id, category_code, is_hidden, is_result, `percentage`, icon_url, `name`, `help`, `sign`, value_load) 
    SELECT d.id, a.parent_id, a.order, a.flag_id, a.category_code, a.is_hidden, a.is_result, a.percentage, a.icon_url, a.name, a.help, a.sign, a.value_load FROM $sp_customcategories AS a
    LEFT JOIN surveycode AS b ON b.id='$sc_id'
    LEFT JOIN $sp_table AS c ON c.survey_code_id = b.id
    LEFT JOIN basetemplates As d on d.template_name = '$sp_header_user'
    WHERE c.survey_page_header_user = '$sp_header_user' AND a.base_template_id = c.$sp_template_id");
      $stmt->execute();
      echo "success";
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// When click update templates
if ($_POST["type"] == "update_template") {
  $level_id = $_POST["level_id"];
  $sc_id = $_POST["sc_id"];
  $sp_template_id = $_POST["sp_template_id"];
  $sp_table = "level" . $level_id . "surveypages";
  try {
    $del_old_template = $conn->prepare("DELETE FROM basetemplates WHERE id = '$sp_template_id'");
    $del_old_template->execute();
    $del_old_category = $conn->prepare("DELETE FROM basecategories WHERE base_template_id='$sp_template_id'");
    $del_old_category->execute();
    echo "success";
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

if ($_POST["type"] == "get_url_by_dblclick") {
  $tr_id = $_POST["tr_id"];
  $data = array();
  try {
    $stmt = $conn->prepare("SELECT a.survey_code_hash, b.username_hash, b.password_hash FROM surveycode AS a
    LEFT JOIN surveylogin AS b ON a.survey_login_id = b.id
    LEFT JOIN surveypageorder AS c ON c.surveycode_id = a.id
    WHERE c.id = '$tr_id'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $data["username_hash"] = $temp["username_hash"];
        $data["password_hash"] = $temp["password_hash"];
        $data["survey_code_hash"] = $temp["survey_code_hash"];
      }
      echo json_encode($data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Recommendation table
if ($_POST["type"] == "init_recommendation") {
  $level_id = $_POST["level_id"];
  $sc_id = $_POST["sc_id"];
  $recommend_table = "level" . $level_id . "recommend";
  $surveypage_table = "level" . $level_id . "surveypages";
  $customcategories_id = "level" . $level_id . "customcategories_template_id";
  $current_time = date_create();
  $current_time = date_timestamp_get($current_time);
  $data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT a.*, b.survey_page_header_user as survey_page FROM $recommend_table as a
    left join $surveypage_table as b on a.survey_code_id = b.survey_code_id and a.template_id=b.$customcategories_id
    where a.survey_code_id = '$sc_id'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $second = $current_time - $temp["created_at"];
        $ago_day = (int)($second / 86400);
        $ago_hour = (int)(($second % 86400) / 3600);
        $ago_min = (int)((($second % 86400) % 3600) / 60);
        $ago_second = $second - $ago_day * 86400 - $ago_hour * 3600 - $ago_min * 60;
        $ago_time = "";
        if($ago_second>0){
          $ago_time = ($ago_second > 1 ? $ago_second . " Seconds ago" : $ago_second . " Second ago");
        }
        if($ago_min > 0){
          $ago_time = ($ago_min > 1 ? $ago_min . " Minutes ago" : $ago_min . " Minute ago");
        }
        if ($ago_day > 0) {
          $ago_time = ($ago_day > 1 ? $ago_day . " days ago" : $ago_day . " day ago");
        }
        $data[$i]["id"] = $temp["id"];
        $data[$i]["survey_page"] = $temp["survey_page"];
        $data[$i]["date"] = $ago_time;
          $data[$i]["recommendation"] = $temp["recommend"];
        $i++;
      }
      echo json_encode($data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Feedback table
if ($_POST["type"] == "init_feedback") {
  $level_id = $_POST["level_id"];
  $sc_id = $_POST["sc_id"];
  $feedback_table = "level" . $level_id . "feedback";
  $surveypage_table = "level" . $level_id . "surveypages";
  $customcategories_id = "level" . $level_id . "customcategories_template_id";
  $current_time = date_create();
  $current_time = date_timestamp_get($current_time);
  $data = array();
  $i = 0;
  try {
    $stmt = $conn->prepare("SELECT a.*, b.survey_page_header_user as survey_page FROM $feedback_table as a
    left join $surveypage_table as b on a.survey_code_id = b.survey_code_id and a.template_id=b.$customcategories_id
    where a.survey_code_id = '$sc_id'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
      $result = $stmt->fetchAll();
      foreach ($result as $temp) {
        $second = $current_time - $temp["created_at"];
        $ago_day = (int)($second / 86400);
        $ago_hour = (int)(($second % 86400) / 3600);
        $ago_min = (int)((($second % 86400) % 3600) / 60);
        $ago_second = $second - $ago_day * 86400 - $ago_hour * 3600 - $ago_min * 60;
        $ago_time = "";
        if($ago_second>0){
          $ago_time = ($ago_second > 1 ? $ago_second . " Seconds ago" : $ago_second . " Second ago");
        }
        if($ago_min > 0){
          $ago_time = ($ago_min > 1 ? $ago_min . " Minutes ago" : $ago_min . " Minute ago");
        }
        if ($ago_day > 0) {
          $ago_time = ($ago_day > 1 ? $ago_day . " days ago" : $ago_day . " day ago");
        }
        $data[$i]["id"] = $temp["id"];
        $data[$i]["survey_page"] = $temp["survey_page"];
        $data[$i]["date"] = $ago_time;
        $data[$i]["feedback"] = $temp["feedback"];
        $i++;
      }
      echo json_encode($data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

//  When click Results Summary
if($_POST["type"] == "results_summary"){
  $sc_id = $_POST["sc_id"];
  $tr_id = $_POST["tr_id"];
  $level_id = $_POST["level_id"];
  $value = $_POST["value"];
  $category_id = $_POST["category_id"];
  $results_table = "level".$level_id."results";
  $customtemplate_id = "level".$level_id."customcategories_template_id";
  $customcategories_id = "level".$level_id."customcategories_id";
  $surveypages = "level".$level_id."surveypages";
  $results_summary_table = "level".$level_id."resultssummary";
  $created_at = date_create();
  $created_at = date_timestamp_get($created_at);
  try{
    $result_query = $conn->prepare("INSERT INTO $results_table SET created_at='$created_at', survey_code_id = '$sc_id', survey_login_id=(SELECT a.survey_login_id FROM surveycode AS a WHERE a.id='$sc_id'),template_id=(SELECT c.$customtemplate_id FROM $surveypages AS c LEFT JOIN surveypageorder AS b ON b.surveypage_id = c.id WHERE b.id='$tr_id'), $customcategories_id='$category_id', is_result='1', surveyed_value='$value'");
    $result_query->execute();
    $result_summary_query = $conn->prepare("INSERT INTO $results_summary_table SET created_at='$created_at', survey_code_id = '$sc_id', survey_login_id=(SELECT a.survey_login_id FROM surveycode AS a WHERE a.id='$sc_id'),
    template_id=(SELECT c.$customtemplate_id FROM $surveypages AS c LEFT JOIN surveypageorder AS b ON b.surveypage_id = c.id WHERE b.id='$tr_id'), is_result='1', 
    surveyed_value_sum=(SELECT SUM(surveyed_value) FROM $results_table WHERE survey_code_id = '$sc_id' AND template_id = (SELECT c.$customtemplate_id FROM $surveypages AS c LEFT JOIN surveypageorder AS b ON b.surveypage_id = c.id WHERE b.id='$tr_id')),
    surveyed_value_number=(SELECT COUNT(id) FROM $results_table WHERE survey_code_id = '$sc_id' AND template_id = (SELECT c.$customtemplate_id FROM $surveypages AS c LEFT JOIN surveypageorder AS b ON b.surveypage_id = c.id WHERE b.id='$tr_id')),    
    surveyed_value_average=(SELECT AVG(surveyed_value) FROM level2results WHERE survey_code_id = '$sc_id' AND template_id = (SELECT c.$customtemplate_id FROM $surveypages AS c LEFT JOIN surveypageorder AS b ON b.surveypage_id = c.id WHERE b.id='$tr_id'))");
    $result_summary_query->execute();
    echo "success";
  }catch(PDOException $e){
    echo "failed".$e->getMessage();
  }
}

//  Hidden row
if($_POST["type"] == "hidden_row"){
  $level_id = $_POST["level_id"];
  $category_id = $_POST["category_id"];
  $customcategories = "level".$level_id."customcategories";
  try{
    $query = $conn->prepare("UPDATE $customcategories SET is_hidden = 1, `percentage` = 0, value_load = 0 WHERE id='$category_id'");
    $query->execute();
  }catch(PDOException $e){
    echo "failed".$e->getMessage();
  }
}

//  Show row
if($_POST["type"] == "show_row"){
  $level_id = $_POST["level_id"];
  $category_id = $_POST["category_id"];
  $customcategories = "level".$level_id."customcategories";
  $value = $_POST["value"];
  $percentage = $_POST["percentage"];
  try{
    $query = $conn->prepare("UPDATE $customcategories SET is_hidden = 0, `percentage` = '$percentage', value_load = '$value' WHERE id='$category_id'");
    $query->execute();
  }catch(PDOException $e){
    echo "failed".$e->getMessage();
  }
}
