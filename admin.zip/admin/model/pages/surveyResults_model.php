<?php
session_start();

include("../../common/env.php");
$db_host = getenv("DB_HOST");
$db_username = getenv("DB_USERNAME");
$db_password = getenv("DB_PASSWORD");
$db_name = getenv("DB_NAME");

$conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_username, $db_password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if($_POST["type"] == "init_surveyResults_table"){
  $sc_id = $_POST["sc_id"];
  $user_email = $_POST["user_email"];
  $data = array();
  $i = 0;
  try{
    $results_query = $conn->prepare("");
  }catch(PDOException $e){
    echo "failed".$e->getMessage();
  }
}