<?php
session_start();

include("../../common/env.php");
$db_host = getenv("DB_HOST");
$db_username = getenv("DB_USERNAME");
$db_password = getenv("DB_PASSWORD");
$db_name = getenv("DB_NAME");

$conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_username, $db_password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_POST["type"] == "init_surveyResults_table") {
  $sc_id = $_POST["sc_id"];
  $user_email = $_POST["user_email"];
  $data = array();
  $i = 0;
  $n = 0;
  try {
    while ($n <= 4) {
      $surveypage = "level" . ($n + 1) . "surveypages";
      $results_query = $conn->prepare("SELECT a.id, a.survey_page_header_user AS sp_header,b.survey_code_name AS sc_name, b.survey_code_hash AS sc_hash FROM $surveypage AS a
    LEFT JOIN surveycode AS b ON b.id = a.survey_code_id 
    WHERE b.id = '$sc_id'");
      $results_query->execute();
      if ($results_query->rowCount() > 0) {
        $results = $results_query->fetchAll();
        foreach ($results as $temp) {
          $data[$n][$i]["id"] = $temp["id"];
          $data[$n][$i]["user_email"] = $user_email;
          $data[$n][$i]["sp_header"] = $temp["sp_header"];
          $data[$n][$i]["sc_name"] = $temp["sc_name"];
          $data[$n][$i]["sc_hash"] = $temp["sc_hash"];
          $i++;
        }
      }
      $n++;
    }
    echo json_encode($data);
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}
