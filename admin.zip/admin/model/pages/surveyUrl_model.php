<?php
session_start();

include("../../common/env.php");
$db_host = getenv("DB_HOST");
$db_username = getenv("DB_USERNAME");
$db_password = getenv("DB_PASSWORD");
$db_name = getenv("DB_NAME");

$conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_username, $db_password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_POST["type"] == "init_url_table") {
  $user_email = $_POST["user_email"];
  $data = array();
  $i = 0;
  try {
    $url_query = $conn->prepare("SELECT a.*, c.email, COUNT(d.id) AS num FROM surveycode AS a
    LEFT JOIN surveylogin AS b ON b.id = a.survey_login_id
    LEFT JOIN `user` AS c ON b.user_id = c.id
    LEFT JOIN surveypageorder AS d ON d.surveycode_id = a.id
    WHERE c.email = '$user_email'
    GROUP BY a.id");
    $url_query->execute();
    if ($url_query->rowCount() > 0) {
      $result = $url_query->fetchAll();
      foreach ($result as $temp) {
        $data[$i]["id"] = $temp["id"];
        $data[$i]["email"] = $temp["email"];
        $data[$i]["sc_name"] = $temp["survey_code_name"];
        $data[$i]["sc_hash"] = $temp["survey_code_hash"];
        $data[$i]["pages"] = $temp["num"];
        $data[$i]["page"] = "<span class='add_page'>Add</span>";
        $data[$i]["responses"] = $temp["max_responses"];
        $data[$i]["expire"] = $temp["expire_date"];
        $data[$i]["generate"] = "<span class='generate'>Copy</span>";
        $i++;
      }
      echo json_encode($data);
    }
  } catch (PDOException $e) {
    echo "failed" . $e->getMessage();
  }
}

// Get Url
if($_POST["type"] == "get_url"){
  $tr_id = $_POST["tr_id"];
  $data = array();
  try{
    $url_query = $conn->prepare("SELECT a.survey_code_hash, b.username_hash, b.password_hash FROM surveycode AS a
    LEFT JOIN surveylogin AS b ON b.id = a.survey_login_id
    WHERE a.id = '$tr_id'");
    $url_query->execute();
    if($url_query->rowCount()>0){
      $result = $url_query->fetchAll();
      foreach($result as $temp){
        $data["sc_hash"] = $temp["survey_code_hash"];
        $data["username_hash"] = $temp["username_hash"];
        $data["password_hash"] = $temp["password_hash"];
      }
      echo json_encode($data);
    }
  }catch(PDOException $e){
    echo "failed".$e->getMessage();
  }
}
