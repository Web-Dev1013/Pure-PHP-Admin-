<div class="container message">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12 message-body">
      <div class="px-4 text-center py-5">
        <p class="h2 message-title font-weight-bold text-gold" contenteditable>
          Feedback Closed
        </p>
        <p class="h4 message-content font-weight-bold text-gold" contenteditable>
          This Page is no longer available as it exceeds uses or expiration date
        </p>
        <button class="btn btn-warning text-white font-weight-bold my-3 py-2 px-4">
          <i class="fas fa-cloud-upload-alt fa-lg"></i>
          <span class="px-4 message-update">Update</span>
        </button>
      </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 message-body">
      <div class="px-4 text-center py-5">
        <p class="h2 message-title font-weight-bold text-gold" contenteditable>
          Thank You
        </p>
        <p class="h4 message-content font-weight-bold text-gold" contenteditable>
          Thank you for your responses
        </p>
        <br>
        <button class="btn btn-warning text-white font-weight-bold my-3 py-2 px-4">
          <i class="fas fa-cloud-upload-alt fa-lg"></i>
          <span class="px-4 message-update">Update</span>
        </button>
      </div>
    </div>
  </div>
</div>