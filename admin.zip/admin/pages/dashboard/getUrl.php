<div class="alert alert-success w-25 float-right ">
  <button type="button" class="close" data-dismiss="alert"></button>
  <strong> Success! </strong> <br><span class="notification">Successfully Created</span>
</div>
<div class="alert alert-danger w-25 float-right ">
  <button type="button" class="close" data-dismiss="alert"></button>
  <strong> Failed! </strong><br><span class="notification"> Please fill email field</span>
</div>
<div class="getUrl">
  <div class="getUrl_table mt-3">
    <p class="h3 p-3 text-gold">
      Generate the URL (last column) - copies to clipboard
    </p>
    <div class="mb-5 mt-4">
      <div class="progress mx-3">
      </div>
      <div class="nodes text-secondary text-center d-flex justify-content-between">
        <div>
          <small>Step 1</small>
          <div class="node_company node rounded-circle mx-auto"></div>
          <small>Company</small>
        </div>
        <div>
          <small>Step 2</small>
          <div class="node_login node rounded-circle mx-auto"></div>
          <small>Survey Login</small>
        </div>
        <div>
          <small>Step 3</small>
          <div class="node_code node rounded-circle mx-auto"></div>
          <small>Survey Code</small>
        </div>
        <div>
          <small>Step 4</small>
          <div class="node_page node rounded-circle mx-auto"></div>
          <small>Survey Pages</small>
        </div>
        <div>
          <small>Step 5</small>
          <div class="node_url node rounded-circle mx- bg-white bg-warning"></div>
          <small>Survey URL</small>
        </div>
        <div>
          <small>Step 6</small>
          <div class="node_results node rounded-circle mx-auto bg-white"></div>
          <small>Results</small>
        </div>
      </div>
    </div>
    <div class="search-title w-75 p-2 bg-purple flex-nowrap form-inline justify-content-between my-3">
      <select id="url_search" class="form-control w-75"></select>
      <span class="text-white font-weight-bold mx-auto flex-nowrap">URL Search</span>
    </div>
    <table id="url_table" class="display table table-hover table-bordered" style="width:100%">
      <thead>
        <tr class="bg-light">
          <th style="width: 20%">Username</th>
          <th style="width: 15%">CodeName</th>
          <th style="width: 15%">Code</th>
          <th style="width: 15%">Pages</th>
          <th style="width: 10%">+Page</th>
          <th style="width: 10%">Responses</th>
          <th style="width: 15%">Expires in</th>
          <th style="width: 15%">Generate URL</th>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
  </div>
  <div class="input-group pb-5 pt-4">
    <input id="url" type="text" class="form-control" placeholder="https://leadofone.com/?un=958153f1b8b96ec4c4eb2147429105d9&pw=345DESf1b8b96ec4c4eb2147429105d9&ac=c7b8fd4beba49c9438a829b0a532d30d" readonly>
    <div class="input-group-append px-3">
      <span id="copy_url">
        <i class="fas fa-clipboard-check my-2 fa-lg"></i>
      </span>
    </div>
  </div>
</div>