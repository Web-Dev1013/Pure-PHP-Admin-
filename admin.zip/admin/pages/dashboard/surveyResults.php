<div class="alert alert-success w-25 float-right ">
  <button type="button" class="close" data-dismiss="alert"></button>
  <strong> Success! </strong> <br><span class="notification">Successfully Created</span>
</div>
<div class="alert alert-danger w-25 float-right ">
  <button type="button" class="close" data-dismiss="alert"></button>
  <strong> Failed! </strong><br><span class="notification"> Please fill email field</span>
</div>
<div class="getUrl">
  <div class="getUrl_table mt-3">
    <p class="h3 p-3 text-gold">
      Generate the URL (last column) - copies to clipboard
    </p>
    <div class="mb-5 mt-4">
      <div class="progress mx-3">
      </div>
      <div class="nodes text-secondary text-center d-flex justify-content-between">
        <div>
          <small>Step 1</small>
          <div class="node_company node rounded-circle mx-auto"></div>
          <small>Company</small>
        </div>
        <div>
          <small>Step 2</small>
          <div class="node_login node rounded-circle mx-auto"></div>
          <small>Survey Login</small>
        </div>
        <div>
          <small>Step 3</small>
          <div class="node_code node rounded-circle mx-auto"></div>
          <small>Survey Code</small>
        </div>
        <div>
          <small>Step 4</small>
          <div class="node_page node rounded-circle mx-auto"></div>
          <small>Survey Pages</small>
        </div>
        <div>
          <small>Step 5</small>
          <div class="node_url node rounded-circle mx-auto"></div>
          <small>Survey URL</small>
        </div>
        <div>
          <small>Step 6</small>
          <div class="node_results node rounded-circle mx-auto bg-warning"></div>
          <small>Results</small>
        </div>
      </div>
    </div>
    <div class="search-title w-75 p-2 bg-purple flex-nowrap form-inline justify-content-between my-3">
      <select id="results_search" class="form-control w-75"></select>
      <span class="text-white font-weight-bold mx-auto flex-nowrap">Results Search</span>
    </div>
    <table id="results_table" class="display table table-hover table-bordered" style="width:100%">
      <thead>
        <tr class="bg-light">
          <th style="width: 20%">User</th>
          <th style="width: 20%">SurveyCode</th>
          <th style="width: 20%">Survey_code_name</th>
          <th style="width: 20%">Survey_page_header</th>
          <th style="width: 20%">Page_display_order_user</th>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
  </div>
  
</div>